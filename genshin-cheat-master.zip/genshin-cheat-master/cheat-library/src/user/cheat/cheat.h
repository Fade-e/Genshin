#pragma once

#include <Windows.h>

namespace cheat 
{
	void Init(HMODULE hModule);
}