#pragma once
namespace util 
{
	bool CloseHandleByName(const wchar_t* name);
}
