using namespace app;

DO_APP_FUNC(0, app::Byte__Array*, Unity_RecordUserData, (int32_t nType));
DO_APP_FUNC(0, Il2CppClass**, GetIl2Classes, ());