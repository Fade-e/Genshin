// Generated C++ file by Il2CppInspector - http://www.djkaty.com - https://github.com/djkaty
// Target Unity version: 2017.4.15 - 2017.4.40

// ******************************************************************************
// * IL2CPP application-specific type definition addresses
// ******************************************************************************

DO_TYPEDEF(0x0B2FD1A8, Byte);
DO_TYPEDEF(0x0B1F7D58, GameManager);
DO_TYPEDEF(0x0B2C39F8, Int32);
DO_SINGLETONEDEF(0x0B1C9380, Singleton_1_MBHLOBDPKEC_);
DO_SINGLETONEDEF(0x0B177D10, Singleton_1_EntityManager_);
DO_SINGLETONEDEF(0x0B1A3FE8, Singleton_1_LoadingManager_);
DO_SINGLETONEDEF(0x0B2138F8, Singleton_1_InteractionManager_);
DO_SINGLETONEDEF(0x0B30B9A8, Singleton_1_UIManager_1_);
DO_SINGLETONEDEF(0x0B1C74D8, Singleton_1_ItemModule_);
DO_SINGLETONEDEF(0x0B1FE4E0, Singleton_1_EventManager_);