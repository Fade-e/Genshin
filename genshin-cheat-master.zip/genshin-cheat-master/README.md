# GenshinCheat
Simple cheat for genshin with protection bypass.

## Status
Some funcitonal can work incorrect with version 2.6.
In the nearest feature it will be fix.

For now the following issues are known: 
- `God mode` don't work (fixed)
- `Map teleport` && `Oculi/Chest teleport` don't work (fixed)
- `Mob vacuum` don't work (partially fixed)
- `Dumb enemies` don't work (fixed)
- `Kill aura` don't work (partially fixed)
- `Infinite stamina` default mode not working. (With `Move sync packet replacement` work fine)

## Features
- [X] Mhyprot bypass
- [X] Check integrity bypass
- [X] Ingame gui
- [X] Map teleportation
- [X] Teleport to chest and oculi
- [X] Infinite sprint with "no send move sync" mode
- [X] Simple features: `God mode`, `Dumb enemies`, `Rapid fire`, `Auto talk`, `No cooldowns`, `No clip`, `Auto loot`

### Demo
<details>
  <summary>Map tp</summary>
  <img src="https://github.com/CallowBlack/gif-demos/blob/main/genshin-cheat/map-teleport-demo.gif"/>
</details>

<details>
  <summary>No clip</summary>
  <img src="https://github.com/CallowBlack/gif-demos/blob/main/genshin-cheat/noclip-demo.gif"/>
</details>

<details>
  <summary>Tp to oculi</summary>
  <img src="https://github.com/CallowBlack/gif-demos/blob/main/genshin-cheat/oculi-teleport-demo.gif"/>
</details>

<details>
  <summary>Tp to chest</summary>
  <img src="https://github.com/CallowBlack/gif-demos/blob/main/genshin-cheat/chest-teleport-demo.gif"/>
</details>

<details>
  <summary>Rapid fire</summary>
  <img src="https://github.com/CallowBlack/gif-demos/blob/main/genshin-cheat/rapid-fire-demo.gif"/>
</details>

<details>
  <summary>Auto talk</summary>
  <img src="https://github.com/CallowBlack/gif-demos/blob/main/genshin-cheat/auto-talk-demo.gif"/>
</details>

## Planned
- [ ] Scene skip
- [ ] Create database of all chests, oculi locations
- [ ] etc...

## Usage

1. Build solution `genshincheat.sln`.
2. Insure that `CLibrary.dll` is in the same folder that `injector.exe`.
3. Run `injector.exe`.
